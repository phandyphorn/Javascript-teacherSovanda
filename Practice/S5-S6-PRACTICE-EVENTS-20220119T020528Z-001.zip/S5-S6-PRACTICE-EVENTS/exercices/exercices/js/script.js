// // Function 1 (as example)
// function function1(num1, num2) {
//   return (num1 + num2) / 2;
// }
// console.log("test function1:", function1(4, 6));


// // Function 2 (as example)
// // TODO
// let sumString = (s1,s2) => {
//   return s1 + s2;
// }
// let resultOfText = sumString('ronan',' the best');
// console.log("test function2:",resultOfText);


// Function 3 (as example)
// TODO
let array = [4,4,4,4];
// console.log("test function3:",eqaulOrNot);
let firstNum = array[0];
for (let num in [1,array]) {
  if (array[num] == firstNum) {
    result = true;
  }else {
    result = false;
  }
}
console.log(result);


// // Function 4 (as example)
// // TODO

// console.log("test function4:");

// // Function 5 (as example)
// // TODO
// console.log("test function5:");

// // Function 6 (as example)
// // TODO
// console.log("test function6:");

// // Function 7 (as example)
// // TODO
// console.log("test function7:");

// Function 8 (as example)
// TODO
/*let sumTwoArray=(array1,array2)=> {
  let sumNums = 0;
  for (value of array1) {
    sumNums += array2[value];
    return sumNums;
  }
}
let array1 = [1,2,3];
let array2 = [4,4,4];
console.log("test function8:",sumTwoArray);
*/


