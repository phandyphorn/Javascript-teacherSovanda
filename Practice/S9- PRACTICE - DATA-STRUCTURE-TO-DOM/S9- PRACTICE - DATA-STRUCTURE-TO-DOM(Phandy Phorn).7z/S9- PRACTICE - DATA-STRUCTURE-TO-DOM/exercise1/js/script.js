// This is our data structure of TASKS
let tasks = [
  { description: "Do homework", priority: 1 },
  { description: "Wash clothes", priority: 0 },
  { description: "Dream about Javascript", priority: 1 },
];
function displayArray(array) {
  // 1 - From the parent body : create a new div  (class : container)
  let div1 = document.createElement("div");
  div1.classList.add(".container")
  let contain = document.querySelector(".container");
  contain.appendChild(div1)
  // 2 - For all tasks,  create a new div (class : item), and append it the container
  
  
  for (let des of tasks) {
    let div2 = document.createElement('div');
    div2.className = "item";
    div2.textContent = des.description;
    // div2.textContent = element['description'];
    // let color = "red";
// 3- The priority defines the color of your item (1 (HIGHT) = red, 0 (LOW) = grey)
    if (des.priority === 1) {
      div2.style.background = "red";
    }else if (des.priority === 0) {
      div2.style.background = "gray"
    }
    // div2.style["background-color"] = color;
    div1.appendChild(div2);
  }
}
displayArray(tasks);
