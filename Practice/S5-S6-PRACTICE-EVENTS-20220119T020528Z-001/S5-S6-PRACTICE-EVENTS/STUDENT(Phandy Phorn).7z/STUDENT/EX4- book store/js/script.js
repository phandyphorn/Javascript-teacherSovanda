//  FUNCTIONS -------------------------------------------------------------
function addBook(event) {
  // event.preventDefault();
  // 1- Get the book name from the input field
  let bookName = document.querySelector("#add-book-textfield");
    // 2- Create a new span bookName for the book name, class name = name
  let spanForBook = document.createElement('span');
  spanForBook.classList.add('name');
  spanForBook.textContent = bookName.value;
    // 3- Create a new span deleteBtn for the button delete, class name = delete
  let spanForDelete = document.createElement('span');
  spanForDelete.classList.add("delete");
  spanForDelete.textContent = "delete";
    // 4- Create a new li
  let li = document.createElement('li');
    // 5- Add bookName and deleteBtn to li and li to the  bookList UL
  li.appendChild('spanForBook');
  li.appendChild('spanForDelete');
  ul.appendChild(li)

  bookName.value = "";
}



function deleteBook(event) {
  // find the index of delete which click 
  // 1- Check the event if raised on the button delete 
 //  2  if yes, get the parent and remove it from the  bookList
  if (event.target.className === "delete") {
    event.target.parentElement.remove();
  }
}


function searchBook(event) {
  // 1- Get the search text
  let title = searchBook.value;
  let titles = document.querySelectorAll('li');
  for (tit of titles) {
    let t = titles.firstElementChild.textContent.toLocaleLowerCase();
    if (t.indexOf(text) === -1) {
      t.style.display = "none";
    }else {
      t.style.display = "block";
    }
  }

  // 2- Loop on all LI
 
    // Update the style of the LI (visible or hidden)

  }

// //  MAIN -------------------------------------------------------------
let buttonAddBook = document.querySelector("button");
let ul = document.querySelector('ul')
buttonAddBook.addEventListener("click", addBook);


let bookList = document.querySelector("#book-list ul")
bookList.addEventListener('click',deleteBook)


let searchBookInput = document
  .getElementById("search-books")
  .querySelector("input");
searchBookInput.addEventListener("keyup", searchBook);
